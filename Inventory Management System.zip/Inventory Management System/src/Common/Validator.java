/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

/**
 *
 * @author abuba
 */
public class Validator {

    public boolean IsNameValid(String name) {
        int i = 0;
        if (name.length() <= 50 && name.length() >= 3) {
            for (char ch : name.toCharArray()) {
                if (((i == 0) && (ch == '0' || ch == '1' || ch == '2' || ch == '3' || ch == '4' || ch == '5' || ch == '6' || ch == '7' || ch == '8' || ch == '9')) || ((i != 0) && (ch == ' '))) {
                    return false;
                }
                i++;
            }
            return true;
        }
        return false;
    }

    public boolean IsPriceValid(int d) {
        if (d < 1000 && d >= 5) {
            return true;
        }
        return false;
    }

    public boolean IsQuantityValid(int s) {
        if (s == 0) 
            return false;
        
        return true;

    }
}
