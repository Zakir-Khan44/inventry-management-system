/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL;

import java.io.*;

public class DataBaseConnector {

    public boolean AddtoDB(String name, int price, int quantity) throws IOException {
        BufferedWriter BWN = new BufferedWriter(new FileWriter("Stock.txt", true));
        BWN.write(name + "." + price + "." + quantity +"."+"\n");
        BWN.close();
        return true;
    }

    public String SearchItem(String name) throws FileNotFoundException, IOException {
        BufferedReader BR = new BufferedReader(new FileReader("Stock.txt"));
        String s;
        while ((s = BR.readLine()) != null) {
            String str[] = s.split(".");
            if (str[0].equals(name)) {
                return "Name:" + str[0] + " " + "Price: " + str[1] + " " + "Quantity Left" + str[2];
            }
        }
        return "Sorry the Item is not available currently please try again later!";
    }

}
