/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAL;

import DML.SearchValidator;
import java.io.IOException;

public class DALController {

    public boolean Add(String name, int price, int quantity) throws IOException {
        DataBaseConnector DBC = new DataBaseConnector();
        return DBC.AddtoDB(name, price, quantity);

    }
    public String Searching(String name) throws IOException
    {   DML.SearchValidator validate=new SearchValidator();
        if (validate.Validator(name)==false)
            return "Name is Incorrect!";
        DataBaseConnector DBC=new DataBaseConnector();
       return DBC.SearchItem(name);
    }
}
