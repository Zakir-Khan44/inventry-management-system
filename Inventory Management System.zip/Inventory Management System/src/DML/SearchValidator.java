/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DML;

import Common.Validator;

/**
 *
 * @author abuba
 */
public class SearchValidator {
    public boolean Validator(String name)
    {  Common.Validator valid= new Validator();
       return valid.IsNameValid(name);
    }
}
