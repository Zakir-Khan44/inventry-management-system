/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DML;

import Common.Validator;
import java.io.IOException;

/**
 *
 * @author abuba
 */
public class ItemValidator {
    public String Validator(ItemDT Item) throws IOException {
        Common.Validator validator = new Validator();
        if (validator.IsNameValid(Item.name) == false) {
            return "Invalid Name!";
        } else if (validator.IsPriceValid(Item.price) == false) {
            return "Invalid Price!";
        } else if (validator.IsQuantityValid(Item.quantity) == false) {
            return "Invalid Quantity!";
        }

        return "True";
    }
}
