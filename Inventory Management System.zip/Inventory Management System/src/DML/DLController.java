/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DML;

import Common.Validator;
import DAL.DALController;
import java.io.IOException;

public class DLController {

    public String AddItem(ItemDT item) throws IOException {
        ItemValidator validator=new ItemValidator();
        if(validator.Validator(item)=="True")
        {DALController dal = new DALController();
        if (dal.Add(item.name, item.price, item.quantity) == false) {
            return "Oops! Could not connect to DataBase,Please try again later.";
        }
        }
        else if(validator.Validator(item)!="True")
            return validator.Validator(item);
        return "Item has been added successfully!";
    }
    public String Search(String name) throws IOException
    { Common.Validator val=new Validator();
      if (val.IsNameValid(name)==false)
          return "Invalid Name!";
      DAL.DALController DC=new DALController();
      return DC.Searching(name);
    
    }
}
